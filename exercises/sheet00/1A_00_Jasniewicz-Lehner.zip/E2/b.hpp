#pragma once

float* b_func(float limit=1e10, int steps=100);
float* b_func_stable(float limit=1e10, int steps=100);