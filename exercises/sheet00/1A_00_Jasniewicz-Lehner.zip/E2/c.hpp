#pragma once

float* c_func(float limit=1e10, int steps=100);
float* c_func_stable(float limit=1e10, int steps=100);