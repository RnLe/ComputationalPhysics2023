#pragma once

float* a_func(float limit=1e10, int steps=100);
float* a_func_stable(float limit=1e10, int steps=100);
