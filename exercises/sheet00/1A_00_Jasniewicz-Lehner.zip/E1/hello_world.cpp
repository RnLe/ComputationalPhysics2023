// This is a single-line comment
/*  
    This is a
    multiline-comment
*/
#include <iostream>    // used for 'cout'

using namespace std;   // to use 'cout' directly instead of typing 'std::cout'

int main() {
    cout << "Hello, World!" << endl;
    return 0;
}