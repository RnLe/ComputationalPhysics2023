# Der Tag, an dem ich ver-Apple-d wurde.

# Siehe PDF:Vorwort für die Erklärung.
# Selbstverständlich aber ist der Programmierer für eine gute Source-Control verantwortlich.
# Dieses Problem war vermeidbar.